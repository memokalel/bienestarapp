import { Brain, Target, Repeat } from 'lucide-react';
import { OnboardingStep } from '../types/onboarding';

export const ONBOARDING_STEPS: OnboardingStep[] = [
  {
    title: '¡Bienvenido a tu viaje de bienestar!',
    description: 'Vamos a personalizar tu experiencia para ayudarte a alcanzar tus objetivos.',
  },
  {
    title: 'Establece tus metas',
    description: 'Elige las áreas en las que quieres enfocarte.',
    options: [
      { id: 'health', icon: Brain, label: 'Salud Mental' },
      { id: 'productivity', icon: Target, label: 'Productividad' },
      { id: 'mindfulness', icon: Repeat, label: 'Mindfulness' },
    ],
  },
  {
    title: 'Personaliza tus hábitos',
    description: 'Selecciona los hábitos que te ayudarán a alcanzar tus metas.',
    requiresValidation: true,
  },
];