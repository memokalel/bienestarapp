import { Brain, Target, Repeat, Sunrise, BookOpen, Clock, Heart, Pencil, List, Moon, Coffee, CheckCircle2 } from 'lucide-react';
import { HabitOption } from '../types/habits';

export const HABITS_BY_CATEGORY: Record<string, HabitOption[]> = {
  health: [
    { id: 'meditation', icon: Brain, label: 'Meditación diaria', description: '10 minutos de mindfulness' },
    { id: 'gratitude', icon: Heart, label: 'Diario de gratitud', description: 'Anotar 3 cosas positivas' },
    { id: 'breathing', icon: Sunrise, label: 'Ejercicios de respiración', description: '5 minutos de respiración consciente' },
  ],
  productivity: [
    { id: 'planning', icon: List, label: 'Planificación del día', description: 'Organizar tareas principales' },
    { id: 'focus', icon: Target, label: 'Modo enfoque', description: '25 minutos de trabajo concentrado' },
    { id: 'review', icon: CheckCircle2, label: 'Revisión de progreso', description: 'Evaluar logros del día' },
  ],
  mindfulness: [
    { id: 'reading', icon: BookOpen, label: 'Lectura consciente', description: '15 minutos de lectura' },
    { id: 'evening', icon: Moon, label: 'Rutina nocturna', description: 'Preparación para dormir' },
    { id: 'morning', icon: Coffee, label: 'Rutina matutina', description: 'Comenzar el día con intención' },
  ],
};