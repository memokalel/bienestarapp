import { useState, useEffect } from 'react';

export function useTimer(duration: number, onComplete: () => void) {
  const [timeLeft, setTimeLeft] = useState(duration * 60);
  const [isRunning, setIsRunning] = useState(false);
  
  useEffect(() => {
    if (!isRunning || timeLeft === 0) return;
    
    const timer = setInterval(() => {
      setTimeLeft(time => {
        if (time === 1) {
          setIsRunning(false);
          onComplete();
        }
        return time - 1;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, [isRunning, timeLeft, onComplete]);
  
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  
  const toggleTimer = () => setIsRunning(!isRunning);
  const resetTimer = () => {
    setIsRunning(false);
    setTimeLeft(duration * 60);
  };

  return {
    timeLeft,
    isRunning,
    toggleTimer,
    resetTimer,
    minutes,
    seconds
  };
}