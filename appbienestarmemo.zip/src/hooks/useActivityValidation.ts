import { habits } from '../types/habits';
import type { Habit } from '../types/habits';

export function useActivityValidation() {
  const findActivityById = (id: string): Habit | null => {
    for (const categoryHabits of Object.values(habits)) {
      const activity = categoryHabits.find(h => h.id === id);
      if (activity) return activity;
    }
    return null;
  };

  const validateActivity = (activity: Habit | null): { 
    isValid: boolean;
    error?: string;
  } => {
    if (!activity) {
      return { isValid: false, error: 'Actividad no encontrada' };
    }

    if (!activity.id || !activity.label) {
      return { isValid: false, error: 'Datos de actividad incompletos' };
    }

    return { isValid: true };
  };

  return {
    findActivityById,
    validateActivity,
  };
}