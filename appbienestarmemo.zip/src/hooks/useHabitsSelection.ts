import { useCallback } from 'react';
import { useStore } from '../store/useStore';
import { HABITS_BY_CATEGORY } from '../constants/habits';
import { HabitOption } from '../types/habits';

export function useHabitsSelection() {
  const { goals, selectedOptions, toggleOption, addHabit } = useStore();

  const availableHabits = useCallback(() => {
    const selectedCategories = goals.map(goal => goal.category);
    return selectedCategories.flatMap(category => 
      HABITS_BY_CATEGORY[category] || []
    );
  }, [goals]);

  const handleHabitSelect = useCallback((habit: HabitOption) => {
    toggleOption(habit.id);
    if (!selectedOptions.has(habit.id)) {
      addHabit({
        id: crypto.randomUUID(),
        userId: 'temp',
        title: habit.label,
        description: habit.description,
        frequency: 'daily',
        completedDates: [],
      });
    }
  }, [selectedOptions, toggleOption, addHabit]);

  return {
    availableHabits,
    handleHabitSelect,
  };
}