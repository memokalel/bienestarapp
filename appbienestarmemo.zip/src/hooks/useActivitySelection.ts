import { useCallback } from 'react';
import { useWellnessStore } from '../store/useWellnessStore';
import type { Habit } from '../types/habits';
import { useActivityValidation } from './useActivityValidation';

export function useActivitySelection() {
  const { selectedHabits, completedActivities } = useWellnessStore();
  const { findActivityById } = useActivityValidation();

  const getFirstPendingActivity = useCallback((): Habit | null => {
    const pendingId = Array.from(selectedHabits)
      .find(id => !completedActivities.has(id));

    if (!pendingId) {
      console.warn('No hay actividades pendientes');
      return null;
    }

    const activity = findActivityById(pendingId);
    if (!activity) {
      console.error('Actividad no válida:', pendingId);
      return null;
    }

    return activity;
  }, [selectedHabits, completedActivities, findActivityById]);

  const isActivityCompleted = useCallback((activityId: string) => {
    return completedActivities.has(activityId);
  }, [completedActivities]);

  return {
    getFirstPendingActivity,
    isActivityCompleted
  };
}