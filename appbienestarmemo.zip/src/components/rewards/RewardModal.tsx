import React from 'react';
import { Trophy, X } from 'lucide-react';

interface Props {
  isOpen: boolean;
  tokens: number;
  onClose: () => void;
}

export function RewardModal({ isOpen, tokens, onClose }: Props) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-md w-full p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-lg hover:bg-gray-100"
        >
          <X className="w-5 h-5 text-gray-500" />
        </button>

        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto">
            <Trophy className="w-8 h-8 text-yellow-500" />
          </div>

          <h3 className="text-xl font-bold text-gray-900">
            ¡Actividad completada!
          </h3>

          <p className="text-gray-600">
            Has ganado {tokens} tokens por completar esta actividad
          </p>

          <button
            onClick={onClose}
            className="w-full py-3 rounded-lg bg-blue-500 text-white font-medium hover:bg-blue-600"
          >
            Continuar
          </button>
        </div>
      </div>
    </div>
  );
}