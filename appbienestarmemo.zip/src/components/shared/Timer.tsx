import React from 'react';
import { Play, Pause, RefreshCw } from 'lucide-react';
import { useTimer } from '../../hooks/useTimer';

interface Props {
  duration: number;
  onComplete: () => void;
}

export function Timer({ duration, onComplete }: Props) {
  const {
    timeLeft,
    isRunning,
    toggleTimer,
    resetTimer,
    minutes,
    seconds
  } = useTimer(duration, onComplete);
  
  return (
    <div className="text-center space-y-4">
      <div className="text-6xl font-mono font-bold text-gray-900">
        {minutes.toString().padStart(2, '0')}:
        {seconds.toString().padStart(2, '0')}
      </div>
      
      <div className="flex justify-center gap-4">
        <button
          onClick={toggleTimer}
          className="p-3 rounded-full bg-blue-100 text-blue-600 hover:bg-blue-200"
        >
          {isRunning ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
        </button>
        
        <button
          onClick={resetTimer}
          className="p-3 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200"
        >
          <RefreshCw className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
}