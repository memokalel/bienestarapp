import React from 'react';
import { ArrowRight } from 'lucide-react';

interface Props {
  onClick: () => void;
  enabled: boolean;
}

export function ContinueButton({ onClick, enabled }: Props) {
  return (
    <button
      onClick={onClick}
      disabled={!enabled}
      className={`
        inline-flex items-center px-6 py-3 rounded-lg font-medium
        transition-colors duration-200
        ${enabled
          ? 'bg-blue-500 text-white hover:bg-blue-600'
          : 'bg-gray-200 text-gray-400 cursor-not-allowed'
        }
      `}
    >
      Continuar
      <ArrowRight className="ml-2 w-5 h-5" />
    </button>
  );
}