import React from 'react';
import { Clock } from 'lucide-react';
import type { Habit } from '../../types/habits';

interface Props {
  habit: Habit;
  isSelected: boolean;
  onSelect: (habitId: string) => void;
}

export function HabitCard({ habit, isSelected, onSelect }: Props) {
  return (
    <button
      onClick={() => onSelect(habit.id)}
      className={`
        w-full text-left p-6 rounded-xl border-2 transition-all duration-200
        ${isSelected
          ? 'border-green-500 bg-green-50'
          : 'border-gray-200 hover:border-gray-300'
        }
      `}
    >
      <div className="flex justify-between items-start mb-2">
        <h3 className={`
          font-medium text-lg
          ${isSelected ? 'text-green-700' : 'text-gray-700'}
        `}>
          {habit.label}
        </h3>
        <div className="flex items-center text-sm text-gray-500">
          <Clock className="w-4 h-4 mr-1" />
          <span>
            {habit.duration} {habit.unit === 'minutes' ? 'min' : 'vez(ces)'}
          </span>
        </div>
      </div>
      
      <p className={`
        text-sm
        ${isSelected ? 'text-green-600' : 'text-gray-500'}
      `}>
        {habit.description}
      </p>
    </button>
  );
}