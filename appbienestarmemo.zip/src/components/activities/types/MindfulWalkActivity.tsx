import React from 'react';
import { Timer } from '../../shared/Timer';

interface Props {
  onComplete: () => void;
}

export function MindfulWalkActivity({ onComplete }: Props) {
  return (
    <div className="space-y-8 text-center">
      <Timer duration={10} onComplete={onComplete} />
      
      <div className="bg-purple-50 p-6 rounded-xl space-y-4">
        <p className="text-purple-700">
          Durante tu caminata, presta atención a:
        </p>
        <ul className="text-purple-600 space-y-2">
          <li>• La sensación de tus pies al tocar el suelo</li>
          <li>• Los sonidos a tu alrededor</li>
          <li>• Tu respiración mientras caminas</li>
          <li>• Los movimientos de tu cuerpo</li>
        </ul>
      </div>
    </div>
  );
}