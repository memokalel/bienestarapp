import React from 'react';
import { Timer } from '../../shared/Timer';
import { ActivityLayout } from '../ActivityLayout';

interface Props {
  onComplete: () => void;
}

export function BreathingActivity({ onComplete }: Props) {
  const [currentStep, setCurrentStep] = React.useState<'inhale' | 'hold' | 'exhale'>('inhale');
  
  React.useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStep(current => {
        switch (current) {
          case 'inhale': return 'hold';
          case 'hold': return 'exhale';
          case 'exhale': return 'inhale';
        }
      });
    }, 4000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <ActivityLayout
      title="Ejercicios de respiración"
      description="Sigue el ritmo para una respiración consciente"
    >
      <div className="space-y-8 text-center">
        <Timer duration={5} onComplete={onComplete} />
        
        <div className={`
          p-8 rounded-full w-48 h-48 mx-auto flex items-center justify-center
          transition-all duration-500
          ${currentStep === 'inhale' ? 'bg-blue-100 scale-100' : ''}
          ${currentStep === 'hold' ? 'bg-green-100 scale-110' : ''}
          ${currentStep === 'exhale' ? 'bg-purple-100 scale-90' : ''}
        `}>
          <p className="text-xl font-medium">
            {currentStep === 'inhale' && 'Inhala'}
            {currentStep === 'hold' && 'Mantén'}
            {currentStep === 'exhale' && 'Exhala'}
          </p>
        </div>

        <div className="bg-gray-50 p-6 rounded-xl">
          <p className="text-gray-600">
            Sigue el ritmo de la animación para una respiración profunda y consciente.
            Inhala por la nariz, mantén el aire, y exhala suavemente por la boca.
          </p>
        </div>
      </div>
    </ActivityLayout>
  );
}