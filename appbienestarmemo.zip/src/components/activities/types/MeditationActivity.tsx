import React from 'react';
import { Timer } from '../../shared/Timer';
import { ActivityLayout } from '../ActivityLayout';

interface Props {
  onComplete: () => void;
}

export function MeditationActivity({ onComplete }: Props) {
  return (
    <ActivityLayout
      title="Meditación guiada"
      description="Encuentra un lugar tranquilo y cómodo. Respira profundamente y sigue la guía."
    >
      <div className="space-y-8 text-center">
        <Timer duration={5} onComplete={onComplete} />
        
        <div className="bg-blue-50 p-6 rounded-xl">
          <p className="text-blue-700 mb-4">
            Cierra tus ojos y concéntrate en tu respiración.
            Observa cómo el aire entra y sale de tu cuerpo.
          </p>
          <p className="text-blue-600">
            Si tu mente divaga, gentilmente tráela de vuelta a tu respiración.
          </p>
        </div>
      </div>
    </ActivityLayout>
  );
}