import React from 'react';
import { Clock, Check, Play } from 'lucide-react';
import type { Habit } from '../../types/habits';

interface Props {
  activity: Habit;
  isCompleted: boolean;
  onStart: () => void;
}

export function ActivityCard({ activity, isCompleted, onStart }: Props) {
  return (
    <div className={`
      p-6 rounded-xl border transition-all duration-200
      ${isCompleted
        ? 'bg-green-50 border-green-200'
        : 'bg-white border-gray-200'
      }
    `}>
      <div className="flex justify-between items-start">
        <div>
          <h3 className={`
            font-medium text-lg mb-1
            ${isCompleted ? 'text-green-700' : 'text-gray-900'}
          `}>
            {activity.label}
          </h3>
          <p className={`
            text-sm mb-4
            ${isCompleted ? 'text-green-600' : 'text-gray-500'}
          `}>
            {activity.description}
          </p>
          <div className="flex items-center text-sm text-gray-500">
            <Clock className="w-4 h-4 mr-1" />
            <span>
              {activity.duration} {activity.unit === 'minutes' ? 'min' : 'vez(ces)'}
            </span>
          </div>
        </div>

        <button
          onClick={onStart}
          disabled={isCompleted}
          className={`
            inline-flex items-center px-4 py-2 rounded-lg transition-colors
            ${isCompleted
              ? 'bg-green-100 text-green-700 cursor-default'
              : 'bg-blue-500 text-white hover:bg-blue-600'
            }
          `}
        >
          {isCompleted ? (
            <>
              <Check className="w-4 h-4 mr-2" />
              Completado
            </>
          ) : (
            <>
              <Play className="w-4 h-4 mr-2" />
              Comenzar
            </>
          )}
        </button>
      </div>
    </div>
  );
}