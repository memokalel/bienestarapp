import React from 'react';
import { useWellnessStore } from '../../store/useWellnessStore';
import { ActivityLayout } from './ActivityLayout';
import { ActivityContent } from './ActivityContent';
import { RewardModal } from '../rewards/RewardModal';
import { ArrowLeft } from 'lucide-react';

export function ActivityScreen() {
  const { currentActivity, setCurrentStep, completeActivity } = useWellnessStore();
  const [showReward, setShowReward] = React.useState(false);

  if (!currentActivity) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <p className="text-xl text-gray-600">
            No hay actividad seleccionada.
          </p>
          <button
            onClick={() => setCurrentStep('results')}
            className="inline-flex items-center px-4 py-2 rounded-lg bg-blue-500 text-white hover:bg-blue-600"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Volver al plan
          </button>
        </div>
      </div>
    );
  }

  const handleComplete = () => {
    completeActivity(currentActivity.id, currentActivity.tokens);
    setShowReward(true);
  };

  const handleContinue = () => {
    setShowReward(false);
    setCurrentStep('results');
  };

  return (
    <div className="max-w-2xl mx-auto">
      <ActivityLayout
        title={currentActivity.label}
        description={currentActivity.description}
      >
        <ActivityContent
          activity={currentActivity}
          onComplete={handleComplete}
        />
      </ActivityLayout>
      
      <RewardModal
        isOpen={showReward}
        tokens={currentActivity.tokens}
        onClose={handleContinue}
      />
    </div>
  );
}