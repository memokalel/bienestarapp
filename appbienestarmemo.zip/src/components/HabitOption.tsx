import React from 'react';
import { HabitOption as HabitOptionType } from '../types/habits';
import { Check } from 'lucide-react';

interface Props {
  habit: HabitOptionType;
  isSelected: boolean;
  onSelect: (habitId: string) => void;
}

export function HabitOption({ habit, isSelected, onSelect }: Props) {
  const Icon = habit.icon;
  
  return (
    <button
      onClick={() => onSelect(habit.id)}
      className={`
        relative p-6 rounded-lg border-2 transition-all duration-200 text-left
        ${isSelected 
          ? 'border-green-500 bg-green-50' 
          : 'border-gray-200 hover:border-green-300'
        }
      `}
    >
      {isSelected && (
        <div className="absolute top-2 right-2">
          <Check className="w-5 h-5 text-green-500" />
        </div>
      )}
      <Icon className={`w-8 h-8 mb-3 ${isSelected ? 'text-green-500' : 'text-gray-600'}`} />
      <h3 className={`font-medium mb-1 ${isSelected ? 'text-green-700' : 'text-gray-800'}`}>
        {habit.label}
      </h3>
      <p className={`text-sm ${isSelected ? 'text-green-600' : 'text-gray-500'}`}>
        {habit.description}
      </p>
    </button>
  );
}