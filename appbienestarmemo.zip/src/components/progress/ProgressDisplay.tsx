import React from 'react';
import { Trophy, Zap, Target } from 'lucide-react';
import type { Progress } from '../../types/wellness';

interface Props {
  progress: Progress;
}

export function ProgressDisplay({ progress }: Props) {
  return (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-gray-900">
        Resultados de tu sesión
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 rounded-xl p-6">
          <div className="flex items-center mb-2">
            <Zap className="w-5 h-5 text-green-500 mr-2" />
            <span className="font-medium text-green-700">Reducción de estrés</span>
          </div>
          <p className="text-2xl font-bold text-green-800">
            {progress.stressReduction}%
          </p>
        </div>

        <div className="bg-blue-50 rounded-xl p-6">
          <div className="flex items-center mb-2">
            <Target className="w-5 h-5 text-blue-500 mr-2" />
            <span className="font-medium text-blue-700">Meta semanal</span>
          </div>
          <p className="text-2xl font-bold text-blue-800">
            {progress.weeklyGoalProgress}%
          </p>
        </div>

        <div className="bg-purple-50 rounded-xl p-6">
          <div className="flex items-center mb-2">
            <Trophy className="w-5 h-5 text-purple-500 mr-2" />
            <span className="font-medium text-purple-700">Tokens ganados</span>
          </div>
          <p className="text-2xl font-bold text-purple-800">
            +{progress.tokens}
          </p>
        </div>
      </div>
    </div>
  );
}