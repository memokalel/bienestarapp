import React from 'react';
import { Trophy } from 'lucide-react';

interface Props {
  progress: number;
  completedCount: number;
  totalCount: number;
  tokens: number;
}

export function ProgressBar({ progress, completedCount, totalCount, tokens }: Props) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex justify-between items-center mb-4">
        <div>
          <h3 className="text-lg font-medium text-gray-900">
            Progreso del día
          </h3>
          <p className="text-gray-600">
            {completedCount}/{totalCount} actividades completadas
          </p>
        </div>
        <div className="flex items-center bg-yellow-50 px-4 py-2 rounded-lg">
          <Trophy className="w-5 h-5 text-yellow-500 mr-2" />
          <span className="font-medium text-yellow-700">{tokens} tokens</span>
        </div>
      </div>

      <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
        <div
          className="h-full bg-green-500 transition-all duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
}