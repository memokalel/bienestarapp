import { LucideIcon, Brain, Wind, Target, Zap, Cloud, Sun } from 'lucide-react';

export type EmotionType = 'stress' | 'anxiety' | 'unfocused' | 'motivated' | 'unmotivated' | 'relaxed';

export interface Emotion {
  id: EmotionType;
  icon: LucideIcon;
  label: string;
  message: string;
  color: string;
}

export const emotions: Record<EmotionType, Emotion> = {
  stress: {
    id: 'stress',
    icon: Wind,
    label: 'Estrés',
    message: 'Encontremos un momento de calma juntos.',
    color: 'rose',
  },
  anxiety: {
    id: 'anxiety',
    icon: Brain,
    label: 'Ansiedad',
    message: 'Respiremos profundo y tomemos un paso a la vez.',
    color: 'purple',
  },
  unfocused: {
    id: 'unfocused',
    icon: Target,
    label: 'Falta de enfoque',
    message: 'Vamos a ayudarte a recuperar tu concentración.',
    color: 'blue',
  },
  motivated: {
    id: 'motivated',
    icon: Zap,
    label: 'Motivado',
    message: '¡Excelente! Aprovechemos esta energía.',
    color: 'yellow',
  },
  unmotivated: {
    id: 'unmotivated',
    icon: Cloud,
    label: 'Desanimado',
    message: 'Paso a paso, hoy daremos un pequeño avance.',
    color: 'gray',
  },
  relaxed: {
    id: 'relaxed',
    icon: Sun,
    label: 'Relajado',
    message: 'Mantengamos este estado de bienestar.',
    color: 'green',
  },
};