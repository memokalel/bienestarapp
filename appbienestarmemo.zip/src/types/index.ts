export interface User {
  id: string;
  email: string;
  name: string;
  goals: Goal[];
  habits: Habit[];
  moodEntries: MoodEntry[];
}

export interface Goal {
  id: string;
  userId: string;
  title: string;
  description: string;
  targetDate: Date;
  completed: boolean;
  category: 'health' | 'productivity' | 'mindfulness' | 'other';
}

export interface Habit {
  id: string;
  userId: string;
  title: string;
  description: string;
  frequency: 'daily' | 'weekly';
  completedDates: Date[];
}

export interface MoodEntry {
  id: string;
  userId: string;
  mood: 1 | 2 | 3 | 4 | 5;
  note: string;
  timestamp: Date;
}