import { create } from 'zustand';
import type { EmotionType } from '../types/emotions';
import type { GoalType } from '../types/goals';
import type { OnboardingStep } from '../types/onboarding';
import type { Activity } from '../types/wellness';

interface WellnessState {
  // Onboarding state
  currentStep: OnboardingStep;
  selectedEmotion: EmotionType | null;
  selectedGoals: Set<GoalType>;
  selectedHabits: Set<string>;
  
  // Activity state
  currentActivity: Activity | null;
  completedActivities: Set<string>;
  tokens: number;
  
  // Actions
  setCurrentStep: (step: OnboardingStep) => void;
  setSelectedEmotion: (emotion: EmotionType | null) => void;
  toggleGoal: (goal: GoalType) => void;
  toggleHabit: (habitId: string) => void;
  setCurrentActivity: (activity: Activity | null) => void;
  completeActivity: (activityId: string, tokensEarned: number) => void;
  clearSelections: () => void;
}

export const useWellnessStore = create<WellnessState>((set) => ({
  // Initial state
  currentStep: 'emotion',
  selectedEmotion: null,
  selectedGoals: new Set(),
  selectedHabits: new Set(),
  currentActivity: null,
  completedActivities: new Set(),
  tokens: 0,
  
  // Actions
  setCurrentStep: (step) => set({ currentStep: step }),
  setSelectedEmotion: (emotion) => set({ selectedEmotion: emotion }),
  toggleGoal: (goal) => set((state) => {
    const newGoals = new Set(state.selectedGoals);
    if (newGoals.has(goal)) {
      newGoals.delete(goal);
    } else {
      newGoals.add(goal);
    }
    return { selectedGoals: newGoals };
  }),
  toggleHabit: (habitId) => set((state) => {
    const newHabits = new Set(state.selectedHabits);
    if (newHabits.has(habitId)) {
      newHabits.delete(habitId);
    } else {
      newHabits.add(habitId);
    }
    return { selectedHabits: newHabits };
  }),
  setCurrentActivity: (activity) => set({ currentActivity: activity }),
  completeActivity: (activityId, tokensEarned) => set((state) => ({
    completedActivities: new Set([...state.completedActivities, activityId]),
    tokens: state.tokens + tokensEarned,
  })),
  clearSelections: () => set({
    selectedEmotion: null,
    selectedGoals: new Set(),
    selectedHabits: new Set(),
  }),
}));