import { create } from 'zustand';
import { User, Goal, Habit, MoodEntry } from '../types';

interface Store {
  user: User | null;
  currentStep: number;
  goals: Goal[];
  habits: Habit[];
  moodEntries: MoodEntry[];
  selectedOptions: Set<string>;
  setUser: (user: User | null) => void;
  setCurrentStep: (step: number) => void;
  addGoal: (goal: Goal) => void;
  addHabit: (habit: Habit) => void;
  addMoodEntry: (entry: MoodEntry) => void;
  toggleOption: (optionId: string) => void;
  clearSelectedOptions: () => void;
}

export const useStore = create<Store>((set) => ({
  // Estado inicial
  user: null,
  currentStep: 0,
  goals: [],
  habits: [],
  moodEntries: [],
  selectedOptions: new Set(),

  // Acciones
  setUser: (user) => set({ user }),
  setCurrentStep: (step) => set({ currentStep: step }),
  addGoal: (goal) => set((state) => ({ goals: [...state.goals, goal] })),
  addHabit: (habit) => set((state) => ({ habits: [...state.habits, habit] })),
  addMoodEntry: (entry) => set((state) => ({ moodEntries: [...state.moodEntries, entry] })),
  toggleOption: (optionId) => set((state) => {
    const newSelectedOptions = new Set(state.selectedOptions);
    if (newSelectedOptions.has(optionId)) {
      newSelectedOptions.delete(optionId);
    } else {
      newSelectedOptions.add(optionId);
    }
    return { selectedOptions: newSelectedOptions };
  }),
  clearSelectedOptions: () => set({ selectedOptions: new Set() }),
}));