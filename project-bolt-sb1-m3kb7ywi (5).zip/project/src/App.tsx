import React from 'react';
import { EmotionSelector } from './components/onboarding/EmotionSelector';
import { GoalSelector } from './components/onboarding/GoalSelector';
import { HabitSelector } from './components/onboarding/HabitSelector';
import { PersonalizedPlan } from './components/onboarding/PersonalizedPlan';
import { useWellnessStore } from './store/useWellnessStore';

export default function App() {
  const { currentStep } = useWellnessStore();

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-12">
        {currentStep === 'emotion' && <EmotionSelector />}
        {currentStep === 'goals' && <GoalSelector />}
        {currentStep === 'habits' && <HabitSelector />}
        {currentStep === 'results' && <PersonalizedPlan />}
      </div>
    </div>
  );
}