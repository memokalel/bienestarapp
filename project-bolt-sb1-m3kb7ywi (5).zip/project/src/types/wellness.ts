export type MoodType = 'stress' | 'anxiety' | 'unfocused';

export interface Activity {
  id: string;
  type: 'meditation' | 'breathing' | 'reflection';
  duration: number;
  title: string;
  description: string;
  tokens: number;
}

export interface Progress {
  stressReduction: number;
  focusImprovement: number;
  weeklyGoalProgress: number;
  tokens: number;
}

export interface UserStats {
  totalSessions: number;
  totalMinutes: number;
  currentStreak: number;
  tokens: number;
  level: number;
}