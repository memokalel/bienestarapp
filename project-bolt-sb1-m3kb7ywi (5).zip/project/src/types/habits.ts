import { Brain, Heart, Target, Sunrise, BookOpen, Clock, List, Moon, Coffee, CheckCircle2, Pencil, Eye } from 'lucide-react';
import type { GoalType } from './goals';

export interface Habit {
  id: string;
  goalType: GoalType;
  label: string;
  description: string;
  duration: number;
  unit: 'minutes' | 'times';
  tokens: number;
}

export const habits: Record<GoalType, Habit[]> = {
  mental_health: [
    {
      id: 'meditation',
      goalType: 'mental_health',
      label: 'Meditar',
      description: 'Práctica de meditación guiada para reducir el estrés',
      duration: 5,
      unit: 'minutes',
      tokens: 5,
    },
    {
      id: 'gratitude',
      goalType: 'mental_health',
      label: 'Diario de gratitud',
      description: 'Escribe 3 cosas por las que estás agradecido hoy',
      duration: 1,
      unit: 'times',
      tokens: 3,
    },
    {
      id: 'breathing',
      goalType: 'mental_health',
      label: 'Ejercicios de respiración',
      description: 'Técnicas de respiración para la calma y el bienestar',
      duration: 5,
      unit: 'minutes',
      tokens: 3,
    },
  ],
  productivity: [
    {
      id: 'planning',
      goalType: 'productivity',
      label: 'Planificación diaria',
      description: 'Organiza tus tareas principales del día',
      duration: 5,
      unit: 'minutes',
      tokens: 3,
    },
    {
      id: 'task_list',
      goalType: 'productivity',
      label: 'Lista de tareas',
      description: 'Crea y prioriza tus pendientes del día',
      duration: 1,
      unit: 'times',
      tokens: 2,
    },
    {
      id: 'daily_review',
      goalType: 'productivity',
      label: 'Revisión de objetivos',
      description: 'Evalúa tu progreso y ajusta tus metas',
      duration: 5,
      unit: 'minutes',
      tokens: 3,
    },
  ],
  mindfulness: [
    {
      id: 'mindful_walk',
      goalType: 'mindfulness',
      label: 'Caminata consciente',
      description: 'Camina prestando atención a tus sentidos',
      duration: 10,
      unit: 'minutes',
      tokens: 5,
    },
    {
      id: 'mindfulness_audio',
      goalType: 'mindfulness',
      label: 'Audio de mindfulness',
      description: 'Escucha una guía de atención plena',
      duration: 10,
      unit: 'minutes',
      tokens: 5,
    },
    {
      id: 'thought_observation',
      goalType: 'mindfulness',
      label: 'Observación de pensamientos',
      description: 'Observa tus pensamientos sin juicios',
      duration: 5,
      unit: 'minutes',
      tokens: 4,
    },
  ],
};