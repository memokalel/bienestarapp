export type OnboardingStep = 'emotion' | 'goals' | 'habits' | 'results';

export interface StepConfig {
  title: string;
  description: string;
  requiresSelection?: boolean;
}