import { Brain, Target, Heart } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

export type GoalType = 'mental_health' | 'productivity' | 'mindfulness';

export interface Goal {
  id: GoalType;
  icon: LucideIcon;
  label: string;
  description: string;
}

export const goals: Record<GoalType, Goal> = {
  mental_health: {
    id: 'mental_health',
    icon: Brain,
    label: 'Salud Mental',
    description: 'Mejora tu bienestar emocional y reduce el estrés',
  },
  productivity: {
    id: 'productivity',
    icon: Target,
    label: 'Productividad',
    description: 'Optimiza tu tiempo y alcanza tus objetivos',
  },
  mindfulness: {
    id: 'mindfulness',
    icon: Heart,
    label: 'Mindfulness',
    description: 'Cultiva la atención plena y la consciencia',
  },
};