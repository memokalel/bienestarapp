import React from 'react';
import { Brain, Wind, Target } from 'lucide-react';
import type { MoodType } from '../../types/wellness';

interface Props {
  onMoodSelect: (mood: MoodType) => void;
  selectedMood: MoodType | null;
}

export function MoodSelector({ onMoodSelect, selectedMood }: Props) {
  const moods = [
    { type: 'stress', icon: Wind, label: 'Estrés', color: 'rose' },
    { type: 'anxiety', icon: Brain, label: 'Ansiedad', color: 'purple' },
    { type: 'unfocused', icon: Target, label: 'Falta de enfoque', color: 'blue' },
  ] as const;

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-center text-gray-900">
        ¿Cómo te sientes hoy?
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {moods.map(({ type, icon: Icon, label, color }) => (
          <button
            key={type}
            onClick={() => onMoodSelect(type)}
            className={`
              p-6 rounded-xl border-2 transition-all duration-200
              ${selectedMood === type
                ? `border-${color}-500 bg-${color}-50`
                : 'border-gray-200 hover:border-gray-300'
              }
            `}
          >
            <Icon className={`
              w-12 h-12 mx-auto mb-3
              ${selectedMood === type ? `text-${color}-500` : 'text-gray-400'}
            `} />
            <p className={`
              font-medium text-lg
              ${selectedMood === type ? `text-${color}-700` : 'text-gray-700'}
            `}>
              {label}
            </p>
          </button>
        ))}
      </div>
    </div>
  );
}