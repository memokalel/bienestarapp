import React from 'react';
import { useStore } from '../store/useStore';
import { Goal } from '../types';
import { ArrowRight } from 'lucide-react';
import { useOnboarding } from '../hooks/useOnboarding';
import { OnboardingOption } from './OnboardingOption';
import { HabitOption } from './HabitOption';
import { useHabitsSelection } from '../hooks/useHabitsSelection';

export function Onboarding() {
  const { addGoal, currentStep } = useStore();
  const { 
    currentStepData, 
    handleNext, 
    isLastStep, 
    error,
    selectedOptions,
    toggleOption 
  } = useOnboarding();

  const { availableHabits, handleHabitSelect } = useHabitsSelection();
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="max-w-lg mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">{currentStepData.title}</h2>
            <p className="text-gray-600 mb-8">{currentStepData.description}</p>
            
            {currentStepData.options ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                {currentStepData.options.map((option) => (
                  <OnboardingOption
                    key={option.id}
                    option={option}
                    isSelected={selectedOptions.has(option.id)}
                    onSelect={(optionId) => {
                      toggleOption(optionId);
                      if (!selectedOptions.has(optionId)) {
                        const newGoal: Goal = {
                          id: crypto.randomUUID(),
                          userId: 'temp',
                          title: option.label,
                          description: '',
                          targetDate: new Date(),
                          completed: false,
                          category: optionId as any,
                        };
                        addGoal(newGoal);
                      }
                    }}
                  />
                ))}
              </div>
            ) : currentStep === 2 ? (
              <div className="grid grid-cols-1 gap-4 mb-8">
                {availableHabits().map((habit) => (
                  <HabitOption
                    key={habit.id}
                    habit={habit}
                    isSelected={selectedOptions.has(habit.id)}
                    onSelect={() => handleHabitSelect(habit)}
                  />
                ))}
              </div>
            ) : null}
            
            {error && (
              <div className="mb-4 p-3 bg-red-50 text-red-600 rounded-lg">
                {error}
              </div>
            )}
            
            <button
              onClick={handleNext}
              className="bg-blue-500 text-white px-8 py-3 rounded-lg font-medium flex items-center mx-auto hover:bg-blue-600 transition-colors"
            >
              {isLastStep ? 'Comenzar' : 'Continuar'}
              <ArrowRight className="ml-2 w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}