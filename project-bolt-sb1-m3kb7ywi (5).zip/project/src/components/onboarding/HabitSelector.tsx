import React from 'react';
import { habits } from '../../types/habits';
import { useWellnessStore } from '../../store/useWellnessStore';
import { ContinueButton } from './ContinueButton';
import { HabitCard } from './HabitCard';

export function HabitSelector() {
  const { selectedGoals, selectedHabits, toggleHabit, setCurrentStep } = useWellnessStore();

  const availableHabits = React.useMemo(() => {
    return Array.from(selectedGoals).flatMap(goalType => habits[goalType]);
  }, [selectedGoals]);

  const handleContinue = () => {
    setCurrentStep('results');
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Elige los hábitos que quieres desarrollar
        </h2>
        <p className="text-gray-600">
          Selecciona las actividades que mejor se ajusten a tu rutina
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {availableHabits.map((habit) => (
          <HabitCard
            key={habit.id}
            habit={habit}
            isSelected={selectedHabits.has(habit.id)}
            onSelect={toggleHabit}
          />
        ))}
      </div>

      <div className="text-center">
        <ContinueButton
          onClick={handleContinue}
          enabled={selectedHabits.size > 0}
        />
        {selectedHabits.size > 0 && (
          <p className="mt-4 text-lg text-gray-600">
            ¡Excelente selección! Vamos a crear tu plan personalizado.
          </p>
        )}
      </div>
    </div>
  );
}