import React from 'react';
import { emotions } from '../../types/emotions';
import { habits } from '../../types/habits';
import { useWellnessStore } from '../../store/useWellnessStore';
import { ProgressBar } from '../progress/ProgressBar';
import { ActivityList } from '../activities/ActivityList';
import { useActivityNavigation } from '../../hooks/useActivityNavigation';
import { useActivitySelection } from '../../hooks/useActivitySelection';

export function PersonalizedPlan() {
  const { 
    selectedEmotion,
    selectedHabits,
    completedActivities,
    tokens
  } = useWellnessStore();

  const { navigateToActivity } = useActivityNavigation();
  const { getFirstPendingActivity } = useActivitySelection();

  const selectedHabitsList = React.useMemo(() => {
    return Array.from(selectedHabits).map(id => {
      for (const categoryHabits of Object.values(habits)) {
        const habit = categoryHabits.find(h => h.id === id);
        if (habit) return habit;
      }
      return null;
    }).filter((habit): habit is NonNullable<typeof habit> => habit !== null);
  }, [selectedHabits]);

  const totalActivities = selectedHabitsList.length;
  const completedCount = completedActivities.size;
  const progress = (completedCount / totalActivities) * 100;

  const handleStartFirstActivity = () => {
    const firstPending = getFirstPendingActivity();
    if (firstPending) {
      navigateToActivity(firstPending);
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Tu plan de bienestar personalizado
        </h2>
        {selectedEmotion && (
          <p className="text-lg text-gray-600">
            {emotions[selectedEmotion].message}
          </p>
        )}
      </div>

      <ProgressBar
        progress={progress}
        completedCount={completedCount}
        totalCount={totalActivities}
        tokens={tokens}
      />

      <ActivityList activities={selectedHabitsList} />

      {completedCount < totalActivities && (
        <div className="text-center">
          <button
            onClick={handleStartFirstActivity}
            className="inline-flex items-center px-6 py-3 rounded-lg bg-blue-500 text-white hover:bg-blue-600 transition-colors font-medium"
          >
            Comenzar primera actividad pendiente
          </button>
        </div>
      )}
    </div>
  );
}