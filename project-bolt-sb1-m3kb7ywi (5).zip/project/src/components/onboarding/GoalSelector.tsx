import React from 'react';
import { goals } from '../../types/goals';
import { useWellnessStore } from '../../store/useWellnessStore';
import { ContinueButton } from './ContinueButton';

export function GoalSelector() {
  const { selectedGoals, toggleGoal, setCurrentStep } = useWellnessStore();

  const handleContinue = () => {
    setCurrentStep('habits');
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          ¿Qué te gustaría trabajar?
        </h2>
        <p className="text-gray-600">
          Selecciona las áreas en las que quieres enfocarte
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {Object.values(goals).map((goal) => {
          const Icon = goal.icon;
          const isSelected = selectedGoals.has(goal.id);

          return (
            <button
              key={goal.id}
              onClick={() => toggleGoal(goal.id)}
              className={`
                p-6 rounded-xl border-2 transition-all duration-200
                ${isSelected
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300'
                }
              `}
            >
              <Icon className={`
                w-12 h-12 mx-auto mb-4
                ${isSelected ? 'text-blue-500' : 'text-gray-400'}
              `} />
              <h3 className={`
                font-medium text-lg mb-2
                ${isSelected ? 'text-blue-700' : 'text-gray-700'}
              `}>
                {goal.label}
              </h3>
              <p className={`
                text-sm
                ${isSelected ? 'text-blue-600' : 'text-gray-500'}
              `}>
                {goal.description}
              </p>
            </button>
          );
        })}
      </div>

      <div className="text-center">
        <ContinueButton
          onClick={handleContinue}
          enabled={selectedGoals.size > 0}
        />
        {selectedGoals.size > 0 && (
          <p className="mt-4 text-lg text-gray-600">
            ¡Excelente elección! Vamos a personalizar tus hábitos para lograrlo.
          </p>
        )}
      </div>
    </div>
  );
}