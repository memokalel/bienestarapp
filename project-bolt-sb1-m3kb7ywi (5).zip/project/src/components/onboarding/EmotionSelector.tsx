import React from 'react';
import { emotions } from '../../types/emotions';
import { useWellnessStore } from '../../store/useWellnessStore';
import { ContinueButton } from './ContinueButton';

export function EmotionSelector() {
  const { selectedEmotion, setSelectedEmotion, setCurrentStep } = useWellnessStore();

  const handleEmotionSelect = (emotionId: string) => {
    setSelectedEmotion(emotionId as any);
  };

  const handleContinue = () => {
    setCurrentStep('goals');
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          ¿Cómo te sientes hoy?
        </h1>
        <p className="text-xl text-gray-600">
          Selecciona la emoción que mejor refleje tu estado actual
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {Object.values(emotions).map((emotion) => {
          const Icon = emotion.icon;
          const isSelected = selectedEmotion === emotion.id;
          
          return (
            <button
              key={emotion.id}
              onClick={() => handleEmotionSelect(emotion.id)}
              className={`
                p-6 rounded-xl border-2 transition-all duration-200
                ${isSelected
                  ? `border-${emotion.color}-500 bg-${emotion.color}-50`
                  : 'border-gray-200 hover:border-gray-300'
                }
              `}
            >
              <Icon className={`
                w-12 h-12 mx-auto mb-3
                ${isSelected ? `text-${emotion.color}-500` : 'text-gray-400'}
              `} />
              <p className={`
                font-medium text-lg
                ${isSelected ? `text-${emotion.color}-700` : 'text-gray-700'}
              `}>
                {emotion.label}
              </p>
            </button>
          );
        })}
      </div>

      {selectedEmotion && (
        <div className="text-center mt-8 space-y-6">
          <p className="text-lg text-gray-600">
            {emotions[selectedEmotion].message}
          </p>
          <ContinueButton
            onClick={handleContinue}
            enabled={!!selectedEmotion}
          />
        </div>
      )}
    </div>
  );
}