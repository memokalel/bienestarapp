import React from 'react';
import { useStore } from '../store/useStore';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { Calendar, Target, Brain, Smile } from 'lucide-react';

export function Dashboard() {
  const { goals, moodEntries } = useStore();

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Dashboard de Bienestar</h1>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium">Estado de Ánimo</h3>
              <Smile className="w-6 h-6 text-blue-500" />
            </div>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={moodEntries}>
                  <XAxis dataKey="timestamp" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="mood" stroke="#3B82F6" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium">Metas Activas</h3>
              <Target className="w-6 h-6 text-green-500" />
            </div>
            <div className="space-y-4">
              {goals.map((goal) => (
                <div key={goal.id} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={goal.completed}
                    className="w-4 h-4 text-blue-500"
                    onChange={() => {}}
                  />
                  <span className="ml-3 text-sm">{goal.title}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium">Meditación Diaria</h3>
              <Brain className="w-6 h-6 text-purple-500" />
            </div>
            <button className="w-full bg-purple-50 text-purple-700 py-3 rounded-lg font-medium hover:bg-purple-100 transition-colors">
              Comenzar Meditación
            </button>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium">Hábitos</h3>
              <Calendar className="w-6 h-6 text-indigo-500" />
            </div>
            <div className="space-y-4">
              <button className="w-full bg-indigo-50 text-indigo-700 py-3 rounded-lg font-medium hover:bg-indigo-100 transition-colors">
                Registrar Hábito
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}