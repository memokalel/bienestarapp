import React from 'react';
import { OnboardingOption as OptionType } from '../types/onboarding';
import { Check } from 'lucide-react';

interface Props {
  option: OptionType;
  isSelected: boolean;
  onSelect: (optionId: string) => void;
}

export function OnboardingOption({ option, isSelected, onSelect }: Props) {
  const Icon = option.icon;
  
  return (
    <button
      onClick={() => onSelect(option.id)}
      className={`
        relative p-6 rounded-lg border-2 transition-all duration-200
        ${isSelected 
          ? 'border-blue-500 bg-blue-50' 
          : 'border-gray-200 hover:border-blue-300'
        }
      `}
    >
      {isSelected && (
        <div className="absolute top-2 right-2">
          <Check className="w-5 h-5 text-blue-500" />
        </div>
      )}
      <Icon className={`w-12 h-12 mx-auto mb-4 ${isSelected ? 'text-blue-500' : 'text-gray-600'}`} />
      <span className={`font-medium ${isSelected ? 'text-blue-700' : 'text-gray-800'}`}>
        {option.label}
      </span>
    </button>
  );
}