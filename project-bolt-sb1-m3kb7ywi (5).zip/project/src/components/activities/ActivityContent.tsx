import React from 'react';
import type { Habit } from '../../types/habits';
import { MeditationActivity } from './types/MeditationActivity';
import { GratitudeActivity } from './types/GratitudeActivity';
import { BreathingActivity } from './types/BreathingActivity';
import { TaskListActivity } from './types/TaskListActivity';
import { MindfulWalkActivity } from './types/MindfulWalkActivity';
import { ThoughtObservationActivity } from './types/ThoughtObservationActivity';

interface Props {
  activity: Habit;
  onComplete: () => void;
}

export function ActivityContent({ activity, onComplete }: Props) {
  if (!activity) {
    return (
      <div className="text-center p-8">
        <p className="text-gray-600">No se encontró la actividad seleccionada.</p>
      </div>
    );
  }

  const components = {
    meditation: MeditationActivity,
    gratitude: GratitudeActivity,
    breathing: BreathingActivity,
    task_list: TaskListActivity,
    mindful_walk: MindfulWalkActivity,
    thought_observation: ThoughtObservationActivity,
  } as const;

  const ActivityComponent = components[activity.id as keyof typeof components];

  if (!ActivityComponent) {
    return (
      <div className="text-center p-8">
        <p className="text-gray-600">Tipo de actividad no soportado: {activity.id}</p>
      </div>
    );
  }

  return <ActivityComponent onComplete={onComplete} />;
}