import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { useWellnessStore } from '../../store/useWellnessStore';

interface Props {
  title: string;
  description: string;
  children: React.ReactNode;
}

export function ActivityLayout({ title, description, children }: Props) {
  const { setCurrentStep } = useWellnessStore();

  return (
    <div className="space-y-8">
      <div className="flex items-center">
        <button
          onClick={() => setCurrentStep('results')}
          className="p-2 rounded-lg hover:bg-gray-100"
        >
          <ArrowLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="ml-4">
          <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
          <p className="text-gray-600">{description}</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
        {children}
      </div>
    </div>
  );
}