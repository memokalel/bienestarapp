import React from 'react';
import { Timer } from '../../shared/Timer';
import { ActivityLayout } from '../ActivityLayout';

interface Props {
  onComplete: () => void;
}

export function ThoughtObservationActivity({ onComplete }: Props) {
  return (
    <ActivityLayout
      title="Observación de pensamientos"
      description="Observa tus pensamientos sin juzgarlos"
    >
      <div className="space-y-8 text-center">
        <Timer duration={5} onComplete={onComplete} />
        
        <div className="bg-purple-50 p-6 rounded-xl space-y-4">
          <p className="text-purple-700">
            Imagina que tus pensamientos son nubes en el cielo.
            Obsérvalos pasar sin intentar cambiarlos o juzgarlos.
          </p>
          <p className="text-purple-600">
            No hay pensamientos buenos o malos.
            Solo observa cómo vienen y se van.
          </p>
        </div>
      </div>
    </ActivityLayout>
  );
}