import React from 'react';
import { ActivityLayout } from '../ActivityLayout';

interface Props {
  onComplete: () => void;
}

export function GratitudeActivity({ onComplete }: Props) {
  const [entries, setEntries] = React.useState(['', '', '']);
  
  const handleChange = (index: number, value: string) => {
    const newEntries = [...entries];
    newEntries[index] = value;
    setEntries(newEntries);
  };

  const isComplete = entries.every(entry => entry.trim().length > 0);

  return (
    <ActivityLayout
      title="Diario de gratitud"
      description="Escribe 3 cosas por las que estás agradecido hoy"
    >
      <div className="space-y-6">
        {entries.map((entry, index) => (
          <div key={index}>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {index + 1}. Estoy agradecido por...
            </label>
            <textarea
              value={entry}
              onChange={(e) => handleChange(index, e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
              rows={2}
            />
          </div>
        ))}

        <button
          onClick={onComplete}
          disabled={!isComplete}
          className={`
            w-full py-3 rounded-lg font-medium transition-colors
            ${isComplete
              ? 'bg-green-500 text-white hover:bg-green-600'
              : 'bg-gray-200 text-gray-500 cursor-not-allowed'
            }
          `}
        >
          Completar
        </button>
      </div>
    </ActivityLayout>
  );
}