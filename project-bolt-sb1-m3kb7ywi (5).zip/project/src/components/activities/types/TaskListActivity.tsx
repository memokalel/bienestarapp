import React from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { ActivityLayout } from '../ActivityLayout';

interface Props {
  onComplete: () => void;
}

interface Task {
  id: string;
  text: string;
  completed: boolean;
}

export function TaskListActivity({ onComplete }: Props) {
  const [tasks, setTasks] = React.useState<Task[]>([]);
  const [newTask, setNewTask] = React.useState('');

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask.trim()) return;

    setTasks(current => [...current, {
      id: crypto.randomUUID(),
      text: newTask.trim(),
      completed: false
    }]);
    setNewTask('');
  };

  const toggleTask = (taskId: string) => {
    setTasks(current => current.map(task =>
      task.id === taskId ? { ...task, completed: !task.completed } : task
    ));
  };

  const deleteTask = (taskId: string) => {
    setTasks(current => current.filter(task => task.id !== taskId));
  };

  const handleComplete = () => {
    if (tasks.length > 0) {
      onComplete();
    }
  };

  return (
    <ActivityLayout
      title="Lista de tareas"
      description="Organiza tus pendientes del día"
    >
      <div className="space-y-6">
        <form onSubmit={handleAddTask} className="flex gap-2">
          <input
            type="text"
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            placeholder="Añade una nueva tarea..."
            className="flex-1 p-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
          />
          <button
            type="submit"
            className="p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
          >
            <Plus className="w-5 h-5" />
          </button>
        </form>

        <div className="space-y-2">
          {tasks.map(task => (
            <div
              key={task.id}
              className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={task.completed}
                  onChange={() => toggleTask(task.id)}
                  className="w-4 h-4 text-blue-500"
                />
                <span className={task.completed ? 'line-through text-gray-400' : ''}>
                  {task.text}
                </span>
              </div>
              <button
                onClick={() => deleteTask(task.id)}
                className="p-1 text-gray-400 hover:text-red-500"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>

        <button
          onClick={handleComplete}
          disabled={tasks.length === 0}
          className={`
            w-full py-3 rounded-lg font-medium transition-colors
            ${tasks.length > 0
              ? 'bg-green-500 text-white hover:bg-green-600'
              : 'bg-gray-200 text-gray-500 cursor-not-allowed'
            }
          `}
        >
          Completar
        </button>
      </div>
    </ActivityLayout>
  );
}