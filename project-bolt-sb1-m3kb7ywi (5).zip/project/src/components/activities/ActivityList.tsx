import React from 'react';
import type { Habit } from '../../types/habits';
import { ActivityCard } from './ActivityCard';
import { useActivityNavigation } from '../../hooks/useActivityNavigation';
import { useActivitySelection } from '../../hooks/useActivitySelection';

interface Props {
  activities: Habit[];
}

export function ActivityList({ activities }: Props) {
  const { navigateToActivity } = useActivityNavigation();
  const { isActivityCompleted } = useActivitySelection();

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4">
        {activities.map((activity) => (
          <ActivityCard
            key={activity.id}
            activity={activity}
            isCompleted={isActivityCompleted(activity.id)}
            onStart={() => navigateToActivity(activity)}
          />
        ))}
      </div>
    </div>
  );
}