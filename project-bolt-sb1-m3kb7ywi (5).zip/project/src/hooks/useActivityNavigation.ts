import { useCallback } from 'react';
import { useWellnessStore } from '../store/useWellnessStore';
import type { Habit } from '../types/habits';
import { useActivityValidation } from './useActivityValidation';

export function useActivityNavigation() {
  const { setCurrentActivity, setCurrentStep } = useWellnessStore();
  const { findActivityById, validateActivity } = useActivityValidation();

  const navigateToActivity = useCallback((habitId: string | Habit) => {
    const activity = typeof habitId === 'string' 
      ? findActivityById(habitId)
      : habitId;

    const validation = validateActivity(activity);
    
    if (!validation.isValid) {
      console.error(validation.error);
      return;
    }

    setCurrentActivity(activity);
    setCurrentStep('activity');
  }, [setCurrentActivity, setCurrentStep, findActivityById, validateActivity]);

  const navigateToResults = useCallback(() => {
    setCurrentStep('results');
  }, [setCurrentStep]);

  return {
    navigateToActivity,
    navigateToResults
  };
}