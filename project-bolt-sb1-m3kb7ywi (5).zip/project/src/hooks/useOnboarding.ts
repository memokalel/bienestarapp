import { useCallback, useState } from 'react';
import { useStore } from '../store/useStore';
import { ONBOARDING_STEPS } from '../constants/onboarding';

export function useOnboarding() {
  const { currentStep, setCurrentStep, selectedOptions, toggleOption, clearSelectedOptions } = useStore();
  const [error, setError] = useState<string | null>(null);

  const handleNext = useCallback(() => {
    const step = ONBOARDING_STEPS[currentStep];
    
    if (step.requiresValidation && selectedOptions.size === 0) {
      setError('Por favor, selecciona al menos una opción antes de continuar.');
      return;
    }

    setError(null);
    if (currentStep < ONBOARDING_STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
      clearSelectedOptions();
    }
  }, [currentStep, selectedOptions, setCurrentStep, clearSelectedOptions]);

  return {
    currentStep,
    currentStepData: ONBOARDING_STEPS[currentStep],
    handleNext,
    isLastStep: currentStep === ONBOARDING_STEPS.length - 1,
    error,
    selectedOptions,
    toggleOption,
  };
}